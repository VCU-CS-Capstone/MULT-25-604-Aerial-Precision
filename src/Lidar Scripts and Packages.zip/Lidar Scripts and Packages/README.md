# LiDAR Software - MULT 25-604

## Structure

These scripts and packages are needed to run the Unitree L1 LiDAR on the Raspberry Pi. The ROS and LIO packages must run on Ubuntu 20.0.04, as that is the only version of Ubuntu their dependencies are compatible with. 

### Setting up the Pi

A directory called `scripts/` and `scans/` should be created in the home directory, and the Pi should be set to log in automatically. The `point_lio_unilidar` and `unitree_lidar_ros` packages should also be placed in the home directory. 

In order to set up the LIO and ROS packages, follow the README files in their specific directories for setup. They will need to be compiled and confirmed to work before running the bash scripts. If any setup processes fail, try creating a memory swapfile in Ubuntu and using the option "-j4" on any make commands to avoid crashing the Pi. 

Place the two bash scripts in the `scripts/` directory we have created in the home directory. Set the `run_lidar.bash` script to run at startup, and the LIO algorithm should run appropriately and save a scan that is labeled with its timestamp in the `scans/` directory. 

An external library called pdal is required for translating point cloud data types. It can be obtained on Ubuntu by running `sudo apt get pdal`.

The HDMI needs to be set to always "hot" if running headless. This can be done either through a cheap device that simulates HDMI output or by setting it that way in the settings within Ubuntu. 

## bash scripts

There are two bash scripts in this directory. 

The first, `run_lidar.bash`, starts the ROS system on the Pi and then waits a few seconds before automatically running the LIO algorithm. It must be running for the LIO algorithm to be able to communicate with the LiDAR. 

The `run_lio.bash` file is called from the `run_lidar.bash` file and runs the LIO algorithm for a time specified in the section commented appropriately for that purpose, and then saves the scan and converts it to an LAS file. 

## extracting the files

Once the scripts have finished running, the extractable point cloud files will be placed in the scans directory. For use in ArcGIS, they may be directly extracted from that directory and will already be in an LAS format. The PCD format is also available. 
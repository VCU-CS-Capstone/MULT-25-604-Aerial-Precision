# this file is designed to run the lidar ros on startup and begin the lio script once initialized

cd ~/unilidar_sdk/unitree_lidar_ros

# running the source in order for package to work
source devel/setup.bash

# launching the ros system in the background
roslaunch unitree_lidar_ros run_without_rviz.launch &
ros_pid=$!

echo starting

# wait for 5 seconds for stuff to initialize to prevent interference, then
# open new terminal window and run the run_lio file
sleep 5s
gnome-terminal -- bash -c "~/scripts/run_lio.bash; exec bash"

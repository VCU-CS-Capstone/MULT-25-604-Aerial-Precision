# this file is run after the lidar initializes and runs the lio algorithm based on a specified amount of time

cd ~/unilidar_sdk/catkin_point_lio_unilidar/

# run source so the directory's functions operate normally
source devel/setup.bash

# launch the lio algorithm in the background to begin collecting points
roslaunch point_lio_unilidar mapping_unilidar_l1.launch &

# save the process id for killing it later
lio_pid=$!
echo lio started

# sleep for X seconds - modify according to desired LiDAR run time
sleep 30s

echo lidar is finished

# exit the lidar applications in appropriate order
kill -INT $lio_pid

# this sleep allows the LIO to correctly save the point cloud before manipulating it
sleep 8s

cd src/point_lio_unilidar/PCD/

# preparing filenames
time=$( date '+%Y-%m-%d-%H-%M')
filename="/home/grady/scans/$time.pcd"

# copy the scans.pcd to the scans directory in home so it is saved for later reference
cp scans.pcd $filename

#las_filename="/home/grady/scans/$time.las" - old archived line, may be useful later

# translate the pcd file to an las file for ease of conversion/export
pdal translate ~/scans/$time.pcd ~/scans/$time.las
